import React, { useEffect, useRef, useState } from "react";

const AdSenseDiagnostic = () => {
  const [diagnosticInfo, setDiagnosticInfo] = useState({});
  const adRef = useRef(null);

  const logDiagnostic = (key, value) => {
    setDiagnosticInfo(prev => ({ ...prev, [key]: value }));
    console.log(`[AdSense Diagnostic] ${key}:`, value);
  };

  useEffect(() => {
    // Check 1: AdBlock Detection
    if (window.adsbygoogle === undefined) {
      logDiagnostic('adBlocker', 'Likely present - adsbygoogle not defined');
    }

    // Check 2: Document Ready State
    logDiagnostic('documentReady', document.readyState);

    // Check 3: Script Loading
    const scriptElement = document.querySelector('script[src*="pagead2.googlesyndication.com"]');
    logDiagnostic('scriptPresent', !!scriptElement);

    // Check 4: Ad Client ID
    const hasValidClient = document.querySelector('ins[data-ad-client]')?.getAttribute('data-ad-client');
    logDiagnostic('clientIDPresent', !!hasValidClient);

    // Check 5: Page URL
    logDiagnostic('pageURL', window.location.href);
    
    // Check 6: Check if running in iframe
    logDiagnostic('isInIframe', window !== window.top);

    // Check 7: Check SSL status
    logDiagnostic('isSecure', window.location.protocol === 'https:');

    // Monitor ad container
    const observer = new MutationObserver((mutations) => {
      const adContainer = adRef.current;
      if (adContainer) {
        logDiagnostic('adHeight', adContainer.offsetHeight);
        logDiagnostic('adWidth', adContainer.offsetWidth);
        logDiagnostic('adVisibility', window.getComputedStyle(adContainer).display);
      }
    });

    if (adRef.current) {
      observer.observe(adRef.current, { 
        attributes: true, 
        childList: true, 
        subtree: true 
      });
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div>
      <div ref={adRef}>
        <script
          async
          src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7719542074975419"
          crossOrigin="anonymous"
          onError={(e) => logDiagnostic('scriptError', e.message)}
          onLoad={() => logDiagnostic('scriptLoaded', true)}
        />
        <ins
          className="adsbygoogle"
          style={{ display: "block" }}
          data-ad-client="ca-pub-7719542074975419"
          data-ad-slot="3943700191"
          data-ad-format="auto"
          data-full-width-responsive="true"
        />
      </div>
      
      {process.env.NODE_ENV === 'development' && (
        <div style={{ 
          margin: '10px', 
          padding: '10px', 
          border: '1px solid #ccc',
          fontSize: '12px'
        }}>
          <h4>AdSense Diagnostic Info:</h4>
          <pre>{JSON.stringify(diagnosticInfo, null, 2)}</pre>
        </div>
      )}
    </div>
  );
};

export default AdSenseDiagnostic;