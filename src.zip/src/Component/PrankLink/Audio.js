import React, { useEffect, useRef, useState } from 'react';
import PrankBtn from './PrankBtn';
import { Col, Row } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPause } from '@fortawesome/free-solid-svg-icons';
import watermark from "../../img/watermark.png";
import AudioVisualizer from './AudioVisualizer';
import Share from './Share';
import InterstitialAd from './InterstitialAd';
import share from "../../img/share.png";

const Audio = ({ data2 }) => {
    const audioRef = useRef(null);
    const [currentTime, setCurrentTime] = useState('0:00');
    const [totalTime, setTotalTime] = useState('0:00');
    const [isImageLoaded, setIsImageLoaded] = useState(false);
    const [duration, setDuration] = useState(0);
    const [isShareOpen, setIsShareOpen] = useState(false);
    const [isPlaying, setIsPlaying] = useState(false);
    const [showAd, setShowAd] = useState(true);  // Start with ad showing
    const [adClosed, setAdClosed] = useState(false);

    const formatTime = (seconds) => {
        const minutes = Math.floor(seconds / 60);
        const sec = Math.floor(seconds % 60);
        return `${minutes}:${sec < 10 ? '0' : ''}${sec}`;
    };

    // Load Google AdSense script
    useEffect(() => {
        const script = document.createElement('script');
        script.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7719542074975419';
        script.async = true;
        script.crossOrigin = 'anonymous';
        document.head.appendChild(script);

        return () => {
            document.head.removeChild(script);
        };
    }, []);

    // Initialize AdSense ads
    useEffect(() => {
        if (window.adsbygoogle) {
            try {
                (window.adsbygoogle = window.adsbygoogle || []).push({});
            } catch (e) {
                console.error('AdSense error:', e);
            }
        }
    }, []);

    // Load cover image
    useEffect(() => {
        if (data2?.CoverImage) {
            const img = new Image();
            img.src = data2.CoverImage;
            img.onload = () => {
                setIsImageLoaded(true);
            };
        }
    }, [data2?.CoverImage]);

    // Handle audio time updates
    useEffect(() => {
        const audio = audioRef.current;

        const updateTime = () => {
            const current = audio.currentTime;
            const total = audio.duration;
            setCurrentTime(formatTime(current));
            setTotalTime(formatTime(total));
            setDuration(total);
        };

        if (audio) {
            audio.addEventListener('timeupdate', updateTime);
            audio.addEventListener('loadedmetadata', updateTime);

            return () => {
                audio.removeEventListener('timeupdate', updateTime);
                audio.removeEventListener('loadedmetadata', updateTime);
            };
        }
    }, []);

    // Start playing audio when ad is closed
    useEffect(() => {
        if (adClosed && audioRef.current) {
            audioRef.current.volume = 1;
            audioRef.current.muted = false;
            audioRef.current.play()
                .then(() => setIsPlaying(true))
                .catch(error => console.error('Error playing audio:', error));
        }
    }, [adClosed]);

    const onShareClick = () => {
        setIsShareOpen(true);
    };

    const handleAdClose = () => {
        setShowAd(false);
        setAdClosed(true);
    };

    return (
        <div className="full-page-background">
            {showAd && (
                <div className="ad-overlay">
                    <div className="ad-container">
                        <ins
                            className="adsbygoogle"
                            style={{ display: "block" }}
                            data-ad-client="ca-pub-7719542074975419"
                            data-ad-slot="3943700191"
                            data-ad-format="auto"
                            data-full-width-responsive="true"
                        />
                        <button 
                            className="close-ad-btn"
                            onClick={handleAdClose}
                        >
                            Close Ad
                        </button>
                    </div>
                </div>
            )}
            
            <div className="content-container">
                <Row className="content p-0 overflow-hidden flex-grow-1">
                    <Col className="d-flex flex-column align-items-center justify-content-center">
                        <div className="img-div position-relative overflow-hidden rounded-4 d-flex align-items-center justify-content-center border border-white">
                            <audio ref={audioRef} loop onEnded={() => setIsPlaying(false)}>
                                <source src={data2.File} type="audio/mp3" />
                                Your browser does not support the audio tag.
                            </audio>

                            {!isImageLoaded ? (
                                <div className="loading-spinner">
                                    <div className="spinner-border text-light" role="status">
                                        <span className="visually-hidden">Loading...</span>
                                    </div>
                                </div>
                            ) : (
                                <>
                                    <img
                                        src={data2.CoverImage}
                                        alt='prankImage'
                                        className='img-fluid position-absolute'
                                    />

                                    <div>
                                        <div
                                            className="share-btn position-absolute text-black cursor"
                                            onClick={onShareClick}
                                            role="button"
                                            aria-label="Share this content"
                                            tabIndex={0}
                                            style={{
                                                right: "12px",
                                                bottom: "12px",
                                                zIndex: 3
                                            }}
                                        >
                                            <img src={share} alt="share" width={20} style={{ paddingRight: "2px" }} />
                                        </div>
                                        <Share 
                                            show={isShareOpen}
                                            onHide={() => setIsShareOpen(false)}
                                            data2={data2}
                                        />
                                    </div>

                                    <div className='position-absolute text-black' style={{ left: "-22px", top: "-23px", zIndex: 3 }}>
                                        <img src={watermark} alt='Prankster' width={120} />
                                    </div>

                                    <div className='position-absolute text-black cursor w-100 px-2'
                                        style={{
                                            backgroundColor: "rgba(217, 217, 217, 0.4)",
                                            backdropFilter: "blur(20px)",
                                            WebkitBackdropFilter: "blur(20px)",
                                            left: "0", 
                                            bottom: "0px"
                                        }}>
                                        <p className='m-0 mx-auto w-100 pt-2 text-black justify-content-center gap-2'>
                                            <span>{data2.Name}</span>
                                        </p>

                                        <div className='d-flex align-items-center gap-3 justify-content-center'>
                                            {isPlaying && (
                                                <div style={{ width: "40px" }}>
                                                    <div className='pause-btn'>
                                                        <FontAwesomeIcon icon={faPause} className='fs-5' style={{ paddingTop: "10px" }} />
                                                    </div>
                                                </div>
                                            )}
                                            <AudioVisualizer
                                                currentTime={audioRef.current?.currentTime || 0}
                                                totalDuration={duration}
                                            />
                                        </div>
                                    </div>
                                </>
                            )}
                        </div>

                        <div className='mt-3'>
                            <PrankBtn />
                        </div>
                    </Col>
                </Row>
            </div>

            <style>{`
                .ad-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(0, 0, 0, 0.8);
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    z-index: 1000;
                }

                .ad-container {
                    background: white;
                    padding: 20px;
                    border-radius: 8px;
                    position: relative;
                    max-width: 90%;
                    max-height: 90%;
                }

                .close-ad-btn {
                    position: absolute;
                    top: -40px;
                    right: 0;
                    background: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    cursor: pointer;
                }

                .loading-spinner {
                    width: 100%;
                    height: 100%;
                    aspect-ratio: 16/9;
                    background: rgba(0,0,0,0.5);
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    margin: 0 auto;
                }

                .content-container {
                    position: relative;
                    z-index: 2;
                    width: 100%;
                    display: flex;
                    flex-direction: column;
                    min-height: 100vh;
                }

                .content {
                    color: white;
                    text-align: center;
                }
            `}</style>
        </div>
    );
};

export default Audio;