import React, { useEffect } from 'react';

const RedirectToApp = () => {
  useEffect(() => {
    const userAgent = navigator.userAgent;
    const urlParams = new URLSearchParams(window.location.search);
    
    // Log all query parameters
    urlParams.forEach((value, key) => {
      console.log(`${key}: ${value}`);
    });

    const androidPackageName = "com.prank.android";
    const iosAppId = "6739135275";
    
    // Convert all query parameters to a string to append to the URL
    const queryString = `&${[...urlParams.entries()]
      .map(([key, value]) => `${key}=${encodeURIComponent(value)}`)
      .join('&')}`;

    if (/android/i.test(userAgent)) {
      // Redirect for Android with all query parameters
      window.location.href = `https://play.google.com/store/apps/details?id=${androidPackageName}&${queryString}`;
    } else if (/iphone|ipad|ipod/i.test(userAgent)) {
      // Redirect for iOS with all query parameters
      window.location.href = `https://apps.apple.com/us/app/prankster-digital-funny-pranks/id${iosAppId}?${queryString}`;
    }
  }, []);

  return null;  // This component doesn't render anything to the UI
};

export default RedirectToApp;
